-- # A Mysql Backup System
-- # Export created: 2017/11/30 on 07:13
-- # Database : cdinb
SET AUTOCOMMIT = 0 ;
SET FOREIGN_KEY_CHECKS=0 ;

-- # Tabel structure for table `alumnos`
DROP TABLE  IF EXISTS `alumnos`;
CREATE TABLE `alumnos` (
  `id_alumno_a` int(11) NOT NULL AUTO_INCREMENT,
  `id_representante_r` int(11) NOT NULL,
  `nombres_a` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL,
  `apellidos_a` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL,
  `fecha_nacimiento` varchar(15) COLLATE utf8mb4_unicode_ci NOT NULL,
  `edad_a` int(1) NOT NULL,
  `cedula_escolar` varchar(12) COLLATE utf8mb4_unicode_ci NOT NULL,
  `referencia_a` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `fecha_ingreso` date NOT NULL,
  `parentesco_a` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `sexo_a` varchar(12) COLLATE utf8mb4_unicode_ci NOT NULL,
  `caracterizacion_a` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `evaluacion_a` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `status_a` enum('activo','inactivo') COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id_alumno_a`),
  KEY `id_representante` (`id_representante_r`),
  CONSTRAINT `alumnos_ibfk_1` FOREIGN KEY (`id_representante_r`) REFERENCES `representantes` (`id_representante_r`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=64 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `alumnos` (`id_alumno_a`, `id_representante_r`, `nombres_a`, `apellidos_a`, `fecha_nacimiento`, `edad_a`, `cedula_escolar`, `referencia_a`, `fecha_ingreso`, `parentesco_a`, `sexo_a`, `caracterizacion_a`, `evaluacion_a`, `status_a`) VALUES (55, 3, 'Renny eduardo', 'Ontivero Ramos', '2017-06-09', 5, 19610363822, 'sdfsdff', '2017-05-15', 'Madre', 'Masculino', 'wqewqeqwewq', 'dwqwqeqe', 'activo'), 
(63, 11, 'FLOR AMALIA', 'RAMIREZ TRUJILLO', '1998-03-27', 19, 19824446369, 'DESOBEDIENTE', '2018-11-05', 'Padre', 'Femenino', ' ATENCIÃ“N DISPERSA', 'CITA CON FT Y DOCENTE MARBI', 'activo');

-- # Tabel structure for table `atenciones`
DROP TABLE  IF EXISTS `atenciones`;
CREATE TABLE `atenciones` (
  `id_atencion` int(11) NOT NULL AUTO_INCREMENT,
  `id_alumno_a` int(11) NOT NULL,
  `id_especialista_e` int(11) NOT NULL,
  `tipo_atencion` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `fecha_atencion` date NOT NULL,
  `status` enum('Pendiente','Asistida','Inasistida') COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id_atencion`),
  KEY `id_alumno` (`id_alumno_a`),
  KEY `id_especialista` (`id_especialista_e`),
  KEY `fecha_atencion` (`fecha_atencion`),
  CONSTRAINT `atenciones_ibfk_2` FOREIGN KEY (`id_especialista_e`) REFERENCES `especialistas` (`id_especialista_e`) ON UPDATE CASCADE,
  CONSTRAINT `atenciones_ibfk_3` FOREIGN KEY (`id_alumno_a`) REFERENCES `alumnos` (`id_alumno_a`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=114 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `atenciones` (`id_atencion`, `id_alumno_a`, `id_especialista_e`, `tipo_atencion`, `fecha_atencion`, `status`) VALUES (80, 55, 31, 'Evaluacion Grupal', '2017-07-13', 'Asistida'), 
(81, 55, 1, 'Atencion', '2017-07-07', 'Inasistida'), 
(83, 55, 31, 'Atencion', '2017-07-16', 'Asistida'), 
(84, 55, 33, 'Atencion', '2017-07-15', 'Asistida'), 
(85, 55, 31, 'Atencion', '2017-07-28', 'Asistida'), 
(86, 63, 35, 'Evaluacion Grupal', '2017-07-17', 'Asistida'), 
(90, 63, 1, 'Atencion', '2017-07-29', 'Asistida'), 
(91, 63, 32, 'Atencion', '2017-07-04', 'Asistida'), 
(92, 55, 31, 'Atencion', '2017-09-30', 'Asistida'), 
(98, 55, 32, 'Atencion', '2017-10-20', 'Asistida'), 
(99, 55, 31, 'Atencion', '2017-10-19', 'Inasistida'), 
(101, 55, 32, 'Atencion', '2017-10-28', 'Inasistida'), 
(102, 55, 33, 'Atencion', '2017-11-07', 'Inasistida'), 
(103, 55, 31, 'Atencion', '2017-11-03', 'Inasistida'), 
(105, 55, 33, 'Atencion', '2017-10-25', 'Inasistida'), 
(106, 55, 35, 'Atencion', '2017-12-25', 'Asistida'), 
(107, 55, 31, 'Atencion', '2017-12-25', 'Asistida'), 
(108, 55, 32, 'Atencion', '2017-12-25', 'Asistida'), 
(109, 55, 33, 'Atencion', '2017-12-25', 'Pendiente'), 
(111, 55, 32, 'Atencion', '2017-01-03', 'Inasistida'), 
(112, 55, 35, 'Atencion', '2017-01-01', 'Inasistida'), 
(113, 55, 33, 'Atencion', '2017-07-24', 'Inasistida');

-- # Tabel structure for table `bitacora`
DROP TABLE  IF EXISTS `bitacora`;
CREATE TABLE `bitacora` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_usuario` int(11) NOT NULL,
  `accion` varchar(5000) COLLATE utf8mb4_unicode_ci NOT NULL,
  `fecha` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `hora` text COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id_usuario` (`id_usuario`),
  CONSTRAINT `bitacora_ibfk_1` FOREIGN KEY (`id_usuario`) REFERENCES `usuarios` (`id_usuario`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=103 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `bitacora` (`id`, `id_usuario`, `accion`, `fecha`, `hora`) VALUES (35, 1, 'Edito al Alumno: Renny dfsdff Ontivero Ramos', '28/10/2017', '5:13am'), 
(36, 1, 'Edito al Alumno: Renny eduardo Ontivero Ramos', '28/10/2017', '5:14am'), 
(37, 1, 'Edito al Especialista: Javier josegcv Ramirez', '28/10/2017', '5:15am'), 
(38, 1, 'Registro una Atencion al alumno: Renny eduardo Ontivero Ramos con el Especialista RAMON Ontivero Ramos Trabajador Social', '02/11/2017', '11:01am'), 
(39, 1, 'Registro una Atencion al alumno: Renny eduardo Ontivero Ramos con el Especialista Javier josegcv Ramirez Psicologia', '02/11/2017', '11:02am'), 
(40, 1, 'Registro una Atencion al alumno: Renny eduardo Ontivero Ramos con el Especialista Javier josegcv Ramirez Psicologia', '02/11/2017', '11:03am'), 
(41, 1, 'Registro una Atencion al alumno: Renny eduardo Ontivero Ramos con el Especialista RAMON Ontivero Ramos Trabajador Social', '02/11/2017', '11:04am'), 
(42, 1, 'Registro una Atencion al alumno: Renny eduardo Ontivero Ramos con el Especialista ANA TERESA TRUJILLO VARGAS Terapeuta', '02/11/2017', '11:04am'), 
(43, 1, 'Registro una Atencion al alumno: Renny eduardo Ontivero Ramos con el Especialista Javier josegcv Ramirez Psicologia', '02/11/2017', '11:05am'), 
(44, 1, 'Registro una Atencion al alumno: Renny eduardo Ontivero Ramos con el Especialista lolaaaa sdfdsf Docente Educacion Inicial', '02/11/2017', '11:06am'), 
(45, 1, 'Registro una Atencion al alumno: Renny eduardo Ontivero Ramos con el Especialista RAMON Ontivero Ramos Trabajador Social', '02/11/2017', '11:08am'), 
(46, 1, 'Registro una Atencion al alumno: Renny eduardo Ontivero Ramos con el Especialista lolaaaa sdfdsf Docente Educacion Inicial', '02/11/2017', '11:11am'), 
(47, 1, 'Registro una Atencion al alumno: Renny eduardo Ontivero Ramos con el Especialista lolaaaa sdfdsf Docente Educacion Inicial', '02/11/2017', '11:11am'), 
(48, 1, 'Borro al Alumno: Renny eduardo Ontivero Ramos', '10/11/2017', '6:57pm'), 
(49, 1, 'Elimino al Especialista: Javier josegcv Ramirez', '10/11/2017', '6:59pm'), 
(50, 1, 'Edito al Alumno: Javier Eduardo Londom Carrisales', '12/11/2017', '12:15pm'), 
(51, 1, 'Borro al Alumno: FLOR AMALIA RAMIREZ TRUJILLO', '12/11/2017', '12:25pm'), 
(52, 1, 'Borro al Alumno: Javier Jose Ontivero Ramos', '12/11/2017', '12:26pm'), 
(53, 1, 'Borro al Alumno: maria sadsadsada', '12/11/2017', '12:28pm'), 
(54, 1, 'Desactivo al Alumno: Maria Salas', '12/11/2017', '12:30pm'), 
(55, 1, 'Desactivo al Alumno: Renny eduardo Ontivero Ramos', '12/11/2017', '12:30pm'), 
(56, 1, 'Desactivo al Alumno: FLOR AMALIA RAMIREZ TRUJILLO', '12/11/2017', '12:38pm'), 
(57, 1, 'Reemplazo al Representante del alumno:  ', '12/11/2017', '1:06pm'), 
(58, 1, 'Reemplazo al Representante del alumno:  ', '12/11/2017', '1:07pm'), 
(59, 1, 'Reemplazo al Representante del alumno:  ', '12/11/2017', '1:07pm'), 
(60, 1, 'Reemplazo al Representante del alumno: Maria Salas', '12/11/2017', '1:09pm'), 
(61, 1, 'Reemplazo al Representante del alumno: Maria Salas', '12/11/2017', '1:10pm'), 
(62, 1, 'Reemplazo al Representante del alumno: MARIA ramirez', '12/11/2017', '1:11pm'), 
(63, 1, 'Desactivo al Alumno: FLOR AMALIA RAMIREZ TRUJILLO', '12/11/2017', '1:14pm'), 
(64, 1, 'Edito al Alumno: FLOR AMALIA RAMIREZ TRUJILLO', '12/11/2017', '1:43pm'), 
(65, 1, 'Desactivo al Alumno: Renny eduardo Ontivero Ramos', '12/11/2017', '1:47pm'), 
(66, 1, 'Registro al Alumno: sadsadsadsadsa dasdsadsadsadsad', '12/11/2017', '1:53pm'), 
(67, 1, 'Registro al Alumno: saasdsadsadsadsad adsadsadsadsadsad', '12/11/2017', '1:59pm'), 
(68, 1, 'Desactivo al Alumno: saasdsadsadsadsad adsadsadsadsadsad', '12/11/2017', '2:31pm'), 
(69, 1, 'Elimino al Representante: dubraska andrade', '12/11/2017', '3:01pm'), 
(70, 1, 'Elimino al Representante: amalia ramirez', '12/11/2017', '3:02pm'), 
(71, 1, 'Desactivo al Representante: apskdasdd sadsad', '12/11/2017', '3:04pm'), 
(72, 1, 'Edito al Representante: Amalia ramirez', '12/11/2017', '3:05pm'), 
(73, 1, 'Desactivo al Alumno: Javier Eduardo Londom Carrisales', '12/11/2017', '3:30pm'), 
(74, 1, 'Desactivo al Alumno: FLOR AMALIA RAMIREZ TRUJILLO', '12/11/2017', '3:35pm'), 
(75, 1, 'Desactivo al Representante: Amalia ramirez', '12/11/2017', '3:37pm'), 
(76, 1, 'Desactivo al Representante: ANA TERESA TRUJILLO VARGAS', '12/11/2017', '3:37pm'), 
(77, 1, 'Registro al Representante: hOLA pROBANDO jaudhusoaduhsajdhj', '12/11/2017', '3:40pm'), 
(78, 1, 'Edito al Representante: Amalia ramirez', '12/11/2017', '3:51pm'), 
(79, 1, 'Edito al Representante: amalia ramirez', '12/11/2017', '3:53pm'), 
(80, 1, 'Edito al Representante: amalia ramirez', '12/11/2017', '3:55pm'), 
(81, 1, 'Edito al Representante: amalia ramirez', '12/11/2017', '3:56pm'), 
(82, 1, 'Edito al Representante: amalia ramirez', '12/11/2017', '3:57pm'), 
(83, 1, 'Desactivo al Representante: amalia ramirez', '12/11/2017', '8:36pm'), 
(84, 1, 'Edito al Especialista: ANA TERESA TRUJILLO VARGAS', '12/11/2017', '8:58pm'), 
(85, 1, 'Elimino al Especialista: ANA TERESA TRUJILLO VARGAS', '12/11/2017', '8:59pm'), 
(86, 1, 'Elimino al Especialista: ANA TERESA TRUJILLO VARGAS', '12/11/2017', '9:06pm'), 
(87, 1, 'Elimino al Especialista: ANA TERESA TRUJILLO VARGAS', '12/11/2017', '9:22pm'), 
(88, 1, 'Desactivo al Representante: apskdasdd sadsad', '12/11/2017', '9:23pm'), 
(89, 1, 'Edito al Especialista: ANA TERES TRUJILLO VARGAS', '14/11/2017', '5:59pm'), 
(90, 1, 'Desactivo al Especialista: ANA TERES TRUJILLO VARGAS', '14/11/2017', '5:59pm'), 
(91, 1, 'Registro una Atencion al alumno: Renny eduardo Ontivero Ramos con el Especialista ANA TERES TRUJILLO VARGAS Terapeuta', '15/11/2017', '2:51pm'), 
(92, 1, 'Registro una Atencion al alumno: Renny eduardo Ontivero Ramos con el Especialista RAMON Ontivero Ramos Trabajador Social', '15/11/2017', '2:52pm'), 
(93, 1, 'Elimino la Atencion del alumno : Renny eduardo Ontivero Ramos asignada al especialista Armando Ontivero  Docente Educacion Inicial del dia: 2017-07-07', '15/11/2017', '2:56pm'), 
(94, 1, 'Elimino la Atencion del alumno : Renny eduardo Ontivero Ramos asignada al especialista Armando Ontivero  Docente Educacion Inicial del dia: 2017-07-07', '15/11/2017', '3:00pm'), 
(95, 1, 'Elimino la Atencion del alumno : Renny eduardo Ontivero Ramos asignada al especialista Armando Ontivero  Docente Educacion Inicial del dia: 2017-07-07', '15/11/2017', '3:18pm'), 
(96, 1, 'Registro al Alumno: sadsaholaaa assadsadsadsadsa', '18/11/2017', '1:08pm'), 
(97, 1, 'Registro al Alumno: dsadsadsadsadsa dsadsadsadsdsadsa', '18/11/2017', '1:18pm'), 
(98, 1, 'Reemplazo al Representante del alumno: FLOR AMALIA RAMIREZ TRUJILLO', '28/11/2017', '5:45pm'), 
(99, 1, 'Desactivo al Especialista: Armando Ramirez', '28/11/2017', '6:26pm'), 
(100, 1, 'Registro una Consulta de Atencion del alumno: Renny eduardo Ontivero Ramos con el especialista ANA TERES TRUJILLO VARGAS Terapeuta', '29/11/2017', '7:03pm'), 
(101, 1, 'Registro una Consulta de Atencion del alumno: Renny eduardo Ontivero Ramos con el especialista Javier josegcv Ramirez Psicologia', '29/11/2017', '7:08pm'), 
(102, 2, 'Registro una Consulta de Atencion del alumno: Renny eduardo Ontivero Ramos con el especialista lolaaaa sdfdsf Docente Educacion Inicial', '30/11/2017', '12:04pm');

-- # Tabel structure for table `especialistas`
DROP TABLE  IF EXISTS `especialistas`;
CREATE TABLE `especialistas` (
  `id_especialista_e` int(11) NOT NULL AUTO_INCREMENT,
  `nombres_e` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL,
  `apellidos_e` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL,
  `cedula_identidad_e` varchar(12) COLLATE utf8mb4_unicode_ci NOT NULL,
  `especialidad_e` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL,
  `telefono_e` varchar(15) COLLATE utf8mb4_unicode_ci NOT NULL,
  `sexo_e` varchar(12) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status_e` enum('activo','inactivo') COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id_especialista_e`),
  UNIQUE KEY `cedula_identidad` (`cedula_identidad_e`)
) ENGINE=InnoDB AUTO_INCREMENT=47 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `especialistas` (`id_especialista_e`, `nombres_e`, `apellidos_e`, `cedula_identidad_e`, `especialidad_e`, `telefono_e`, `sexo_e`, `status_e`) VALUES (1, 'Armando', 'Ontivero ', 'sadSA', 'Docente Educacion Inicial', 4554, 'Femenino', 'activo'), 
(31, 'Javier josegcv', 'Ramirez', 24446368, 'Psicologia', 565464556, 'Masculino', 'activo'), 
(32, 'lolaaaa', 'sdfdsf', 147896523, 'Docente Educacion Inicial', 45454, 'Femenino', 'activo'), 
(33, 'RAMON', 'Ontivero Ramos', 12345678, 'Trabajador Social', 4545, 'Masculino', 'activo'), 
(34, 'Ronaldo', 'dsaasdsad', 24446367, 'Docente especialista', 546456464, 'Masculino', 'activo'), 
(35, 'ANA TERES', 'TRUJILLO VARGAS', 10363822, 'Terapeuta', 04268796541, 'Femenino', 'activo'), 
(36, 'FTDGD', 'fdsfsdfsdf', 24446361, 'Docente Educacion Inicial', 5424, 'Masculino', 'activo'), 
(45, 'javier', 'Rondom', 24446362, 'Docente especialista', 2147483647, 'Masculino', 'activo'), 
(46, 'Armando', 'Ramirez', 24446364, 'Docente especialista', 548484848, 'Masculino', 'activo');

-- # Tabel structure for table `historiales`
DROP TABLE  IF EXISTS `historiales`;
CREATE TABLE `historiales` (
  `id_historial` int(11) NOT NULL AUTO_INCREMENT,
  `id_atencion` int(11) NOT NULL,
  `observaciones_o` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `fecha_observacion` date NOT NULL,
  PRIMARY KEY (`id_historial`),
  KEY `id_atencion` (`id_atencion`),
  CONSTRAINT `historiales_ibfk_1` FOREIGN KEY (`id_atencion`) REFERENCES `atenciones` (`id_atencion`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `historiales` (`id_historial`, `id_atencion`, `observaciones_o`, `fecha_observacion`) VALUES (7, 81, ' ', '2017-07-07'), 
(8, 83, ' OBSERVACION', '2017-07-16'), 
(9, 84, 'OBSERVACION', '2017-07-15'), 
(10, 90, ' RGTRYTRYTRYRT', '2017-07-29'), 
(11, 91, '                   ', '2017-07-04'), 
(12, 85, ' OBSERVACION', '2017-07-28'), 
(26, 98, 'OBSERVACION', '2017-10-20'), 
(27, 98, 'OBSERVACION', '2017-10-20'), 
(28, 98, 'OBSERVACION', '2017-10-20'), 
(29, 106, 'XZCSADSADSADSAD', '2017-12-25'), 
(30, 107, 'seresrwaesadsadsa', '2017-12-25'), 
(31, 108, 'asdadasdsadsad', '2017-12-25');

-- # Tabel structure for table `representantes`
DROP TABLE  IF EXISTS `representantes`;
CREATE TABLE `representantes` (
  `id_representante_r` int(11) NOT NULL AUTO_INCREMENT,
  `nombres_r` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL,
  `apellidos_r` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL,
  `cedula_identidad_r` varchar(12) COLLATE utf8mb4_unicode_ci NOT NULL,
  `telefono_r` varchar(12) COLLATE utf8mb4_unicode_ci NOT NULL,
  `direccion_r` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `sexo_r` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status_r` enum('activo','inactivo') COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id_representante_r`),
  UNIQUE KEY `numero_cedula` (`cedula_identidad_r`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `representantes` (`id_representante_r`, `nombres_r`, `apellidos_r`, `cedula_identidad_r`, `telefono_r`, `direccion_r`, `sexo_r`, `status_r`) VALUES (2, 'amalia', 'ramirez', 12546545645, 04164348294, 'sadadsadsa', 'femenino', 'activo'), 
(3, 'ANA TERESA', 'TRUJILLO VARGAS', 10363822, 2147483647, 'san mateo UYUIYGYIGYIGYGYGIYGYU', 'Femenino', 'activo'), 
(5, 'Javier Jose', 'Ontivero Ramos', 2212323, 78978978, 'wssadfsaf', 'Femenino', 'activo'), 
(6, 'dubraska', 'andrade', 26987958, 2147483647, 'sadsadsa', 'Femenino', 'activo'), 
(7, 'apskdasdd', 'sadsad', 10363821, 65456464, 'dsadsad', 'Femenino', 'activo'), 
(9, 'mariaaaa', 'edfasdfdsfds', 147896325, 775654654, 'rfdsfdsf', 'Masculino', 'activo'), 
(10, 'Estefania', 'ramirez', 32165498, 1254454, 'sadadsadsa', 'Femenino', 'activo'), 
(11, 'Mario', 'Gonzalez', 24446369, 2147483647, 'sdfhufhdsufhuh', 'Masculino', 'activo'), 
(12, 'sasasweqe', 'asdsdadsadsa', 10359266, 2147483, 'esrsrewrrwr', 'Masculino', 'activo'), 
(13, 'sadsadsadsad', 'sadsadsad', 10359222, 1425, 'sadsdsadsa', 'Masculino', 'activo'), 
(14, 'sadsadsadsadsa', 'asadsadsadsad', 12457865, 1234, 'sadadsad', 'Masculino', 'activo'), 
(15, 'hOLA pROBANDO', 'jaudhusoaduhsajdhj', 10395657, 2147483647, 'dfdsfsdfdsfsdfsdfsdfdsfdsfdsfsd', 'Masculino', 'activo');

-- # Tabel structure for table `usuarios`
DROP TABLE  IF EXISTS `usuarios`;
CREATE TABLE `usuarios` (
  `id_usuario` int(11) NOT NULL AUTO_INCREMENT,
  `usuario` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nombre` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `clave` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `pregunta_secreta` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `respuesta` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nivel` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` enum('activo','inactivo') COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id_usuario`),
  KEY `usuario` (`usuario`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `usuarios` (`id_usuario`, `usuario`, `nombre`, `clave`, `pregunta_secreta`, `respuesta`, `nivel`, `status`) VALUES (1, 'CDINB', 'Directivo', '7c4a8d09ca3762af61e59520943dc26494f8941b', 'Nombre de mi padre', 'Armando', 'Administrador', 'activo'), 
(2, 'USUARIO', 'Ana ', '7c4a8d09ca3762af61e59520943dc26494f8941b', 'Nombre de mi Madre', 'ana', 'Secretaria', 'activo'), 
(3, 'renny', 'renny', '40bd001563085fc35165329ea1ff5c5ecbdbbeef', 'Lugar de Nacimiento', 'Maracay', 'Especialista', 'activo'), 
(4, 'ANA TRUJILLO', 'Loal', '7c4a8d09ca3762af61e59520943dc26494f8941b', 'Nombre de mi Madre', 'FLORA', 'Secretaria', 'inactivo'), 
(5, 'javier123', 'javier', '5ef872a9fa7fcff0677696457dd869535d547e45', 'Nombre de mi Madre', 515454, 'Secretaria', 'inactivo'), 
(6, 'Unknown', 'RENNY', '80a4daded290f572c96be42c3c1b5f9c5a71a810', 'Nombre de mi Madre', 'teresa', 'Especialista', 'activo');

SET FOREIGN_KEY_CHECKS = 1;
COMMIT;
SET AUTOCOMMIT = 1; 
