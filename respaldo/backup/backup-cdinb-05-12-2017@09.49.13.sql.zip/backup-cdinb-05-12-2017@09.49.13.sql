-- # A Mysql Backup System
-- # Export created: 2017/12/05 on 09:49
-- # Database : cdinb
SET AUTOCOMMIT = 0 ;
SET FOREIGN_KEY_CHECKS=0 ;

-- # Tabel structure for table `atenciones`
DROP TABLE  IF EXISTS `atenciones`;
CREATE TABLE `atenciones` (
  `id_atencion` int(11) NOT NULL AUTO_INCREMENT,
  `id_alumno_a` int(11) NOT NULL,
  `id_especialista_e` int(11) NOT NULL,
  `tipo_atencion` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `fecha_atencion` date NOT NULL,
  `status` enum('Pendiente','Asistida','Inasistida') COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id_atencion`),
  KEY `id_alumno` (`id_alumno_a`),
  KEY `id_especialista` (`id_especialista_e`),
  KEY `fecha_atencion` (`fecha_atencion`),
  CONSTRAINT `atenciones_ibfk_2` FOREIGN KEY (`id_especialista_e`) REFERENCES `especialistas` (`id_especialista_e`) ON UPDATE CASCADE,
  CONSTRAINT `atenciones_ibfk_3` FOREIGN KEY (`id_alumno_a`) REFERENCES `alumnos` (`id_alumno_a`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=119 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `atenciones` (`id_atencion`, `id_alumno_a`, `id_especialista_e`, `tipo_atencion`, `fecha_atencion`, `status`) VALUES (114, 70, 47, 'Evaluacion Grupal', '2017-12-18', 'Asistida'), 
(115, 70, 47, 'Atencion', '2017-12-05', 'Pendiente'), 
(116, 70, 47, 'Atencion', '2017-12-06', 'Asistida'), 
(117, 70, 47, 'Atencion', '2017-12-05', 'Pendiente'), 
(118, 70, 47, 'Atencion', '2017-12-06', 'Pendiente');

SET FOREIGN_KEY_CHECKS = 1;
COMMIT;
SET AUTOCOMMIT = 1; 
