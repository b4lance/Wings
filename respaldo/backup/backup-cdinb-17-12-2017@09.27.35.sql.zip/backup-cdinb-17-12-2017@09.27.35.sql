-- # A Mysql Backup System
-- # Export created: 2017/12/17 on 09:27
-- # Database : cdinb
SET AUTOCOMMIT = 0 ;
SET FOREIGN_KEY_CHECKS=0 ;

-- # Tabel structure for table `alumnos`
DROP TABLE  IF EXISTS `alumnos`;
CREATE TABLE `alumnos` (
  `id_alumno_a` int(11) NOT NULL AUTO_INCREMENT,
  `id_representante_r` int(11) NOT NULL,
  `nombres_a` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL,
  `apellidos_a` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL,
  `fecha_nacimiento` varchar(15) COLLATE utf8mb4_unicode_ci NOT NULL,
  `edad_a` int(1) NOT NULL,
  `cedula_escolar` varchar(12) COLLATE utf8mb4_unicode_ci NOT NULL,
  `referencia_a` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `fecha_ingreso` date NOT NULL,
  `parentesco_a` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `sexo_a` varchar(12) COLLATE utf8mb4_unicode_ci NOT NULL,
  `caracterizacion_a` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `evaluacion_a` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `status_a` enum('activo','inactivo') COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id_alumno_a`),
  KEY `id_representante` (`id_representante_r`),
  CONSTRAINT `alumnos_ibfk_1` FOREIGN KEY (`id_representante_r`) REFERENCES `representantes` (`id_representante_r`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=72 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `alumnos` (`id_alumno_a`, `id_representante_r`, `nombres_a`, `apellidos_a`, `fecha_nacimiento`, `edad_a`, `cedula_escolar`, `referencia_a`, `fecha_ingreso`, `parentesco_a`, `sexo_a`, `caracterizacion_a`, `evaluacion_a`, `status_a`) VALUES (70, 16, 'Jose Manuel', 'Ramirez Trujilo', '02/05/2014', 3, 11410363822, 'Falta de atencion', '2017-09-15', 'Madre', 'Masculino', ' Sindrome de DOWN', 'djcdnsjvnndsjfsnjfd', 'activo'), 
(71, 17, 'renny eduardo', 'sgdjshdhsjdjshdjs', '02/05/2014', 3, 11410363821, 'skhdkshkddsd', '2017-08-04', 'Madre', 'Masculino', '', '', 'activo');

-- # Tabel structure for table `atenciones`
DROP TABLE  IF EXISTS `atenciones`;
CREATE TABLE `atenciones` (
  `id_atencion` int(11) NOT NULL AUTO_INCREMENT,
  `id_alumno_a` int(11) NOT NULL,
  `id_especialista_e` int(11) NOT NULL,
  `tipo_atencion` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `fecha_atencion` date NOT NULL,
  `status` enum('Pendiente','Asistida','Inasistida') COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id_atencion`),
  KEY `id_alumno` (`id_alumno_a`),
  KEY `id_especialista` (`id_especialista_e`),
  KEY `fecha_atencion` (`fecha_atencion`),
  CONSTRAINT `atenciones_ibfk_2` FOREIGN KEY (`id_especialista_e`) REFERENCES `especialistas` (`id_especialista_e`) ON UPDATE CASCADE,
  CONSTRAINT `atenciones_ibfk_3` FOREIGN KEY (`id_alumno_a`) REFERENCES `alumnos` (`id_alumno_a`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=117 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `atenciones` (`id_atencion`, `id_alumno_a`, `id_especialista_e`, `tipo_atencion`, `fecha_atencion`, `status`) VALUES (114, 70, 47, 'Evaluacion Grupal', '2017-12-18', 'Asistida'), 
(115, 70, 47, 'Atencion', '2017-12-05', 'Pendiente'), 
(116, 70, 47, 'Atencion', '2017-12-06', 'Pendiente');

-- # Tabel structure for table `bitacora`
DROP TABLE  IF EXISTS `bitacora`;
CREATE TABLE `bitacora` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_usuario` int(11) NOT NULL,
  `accion` varchar(5000) COLLATE utf8mb4_unicode_ci NOT NULL,
  `fecha` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `hora` text COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id_usuario` (`id_usuario`),
  CONSTRAINT `bitacora_ibfk_1` FOREIGN KEY (`id_usuario`) REFERENCES `usuarios` (`id_usuario`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=120 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `bitacora` (`id`, `id_usuario`, `accion`, `fecha`, `hora`) VALUES (109, 1, 'Registro al Representante: Maria Luisa Ramos Rodriguez', '05/12/2017', '8:39am'), 
(110, 1, 'Registro al Alumno: Jose Manuel Ramirez Trujilo', '17/12/2017', '9:08am'), 
(111, 1, 'Registro al Especialista: Maria Jose Vargas Trujillo', '17/12/2017', '9:09am'), 
(112, 1, 'Registro una Evaluacion Grupal al alumno: Jose Manuel Ramirez Trujilo con el Especialista Maria Jose Vargas Trujillo Trabajador Social', '17/12/2017', '9:10am'), 
(113, 1, 'Registro una Consulta de Evaluacion Grupal del alumno: Jose Manuel Ramirez Trujilo con el especialista Maria Jose Vargas Trujillo Trabajador Social', '17/12/2017', '9:11am'), 
(114, 1, 'Registro al Usuario: pueba asignado a: jose', '17/12/2017', '9:17am'), 
(115, 1, 'Registro al Representante: maria luisa ramos bjnbhdjs', '17/12/2017', '9:19am'), 
(116, 1, 'Registro al Alumno: renny eduardo sgdjshdhsjdjshdjs', '17/12/2017', '9:21am'), 
(117, 1, 'Registro al Especialista: javier djsdjhs gsjdjsgdjjdsjdjsdg', '17/12/2017', '9:22am'), 
(118, 1, 'Registro una Atencion al alumno: Jose Manuel Ramirez Trujilo con el Especialista Maria Jose Vargas Trujillo Trabajador Social', '17/12/2017', '9:24am'), 
(119, 1, 'Registro una Atencion al alumno: Jose Manuel Ramirez Trujilo con el Especialista Maria Jose Vargas Trujillo Trabajador Social', '17/12/2017', '9:24am');

-- # Tabel structure for table `especialistas`
DROP TABLE  IF EXISTS `especialistas`;
CREATE TABLE `especialistas` (
  `id_especialista_e` int(11) NOT NULL AUTO_INCREMENT,
  `nombres_e` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL,
  `apellidos_e` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL,
  `cedula_identidad_e` varchar(12) COLLATE utf8mb4_unicode_ci NOT NULL,
  `especialidad_e` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL,
  `telefono_e` varchar(15) COLLATE utf8mb4_unicode_ci NOT NULL,
  `sexo_e` varchar(12) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status_e` enum('activo','inactivo') COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id_especialista_e`),
  UNIQUE KEY `cedula_identidad` (`cedula_identidad_e`)
) ENGINE=InnoDB AUTO_INCREMENT=49 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `especialistas` (`id_especialista_e`, `nombres_e`, `apellidos_e`, `cedula_identidad_e`, `especialidad_e`, `telefono_e`, `sexo_e`, `status_e`) VALUES (47, 'Maria Jose', 'Vargas Trujillo', 24446368, 'Trabajador Social', 04269876543, 'Masculino', 'activo'), 
(48, 'javier djsdjhs', 'gsjdjsgdjjdsjdjsdg', 12345678, 'Docente especialista', 0416786543, 'Masculino', 'activo');

-- # Tabel structure for table `historiales`
DROP TABLE  IF EXISTS `historiales`;
CREATE TABLE `historiales` (
  `id_historial` int(11) NOT NULL AUTO_INCREMENT,
  `id_atencion` int(11) NOT NULL,
  `observaciones_o` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `fecha_observacion` date NOT NULL,
  PRIMARY KEY (`id_historial`),
  KEY `id_atencion` (`id_atencion`),
  CONSTRAINT `historiales_ibfk_1` FOREIGN KEY (`id_atencion`) REFERENCES `atenciones` (`id_atencion`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- # Tabel structure for table `representantes`
DROP TABLE  IF EXISTS `representantes`;
CREATE TABLE `representantes` (
  `id_representante_r` int(11) NOT NULL AUTO_INCREMENT,
  `nombres_r` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL,
  `apellidos_r` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL,
  `cedula_identidad_r` varchar(12) COLLATE utf8mb4_unicode_ci NOT NULL,
  `telefono_r` varchar(12) COLLATE utf8mb4_unicode_ci NOT NULL,
  `direccion_r` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `sexo_r` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status_r` enum('activo','inactivo') COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id_representante_r`),
  UNIQUE KEY `numero_cedula` (`cedula_identidad_r`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `representantes` (`id_representante_r`, `nombres_r`, `apellidos_r`, `cedula_identidad_r`, `telefono_r`, `direccion_r`, `sexo_r`, `status_r`) VALUES (16, 'Maria Luisa', 'Ramos Rodriguez', 10363822, 04264348294, 'San Mateo, Estado Aragua', 'Femenino', 'activo'), 
(17, 'maria luisa', 'ramos bjnbhdjs', 10363821, 04261234567, 'la victoria, estado aragua', 'Femenino', 'activo');

-- # Tabel structure for table `usuarios`
DROP TABLE  IF EXISTS `usuarios`;
CREATE TABLE `usuarios` (
  `id_usuario` int(11) NOT NULL AUTO_INCREMENT,
  `usuario` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nombre` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `clave` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `pregunta_secreta` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `respuesta` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nivel` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` enum('activo','inactivo') COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id_usuario`),
  KEY `usuario` (`usuario`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `usuarios` (`id_usuario`, `usuario`, `nombre`, `clave`, `pregunta_secreta`, `respuesta`, `nivel`, `status`) VALUES (1, 'CDINB', 'Directivo', '7c4a8d09ca3762af61e59520943dc26494f8941b', 'Nombre de mi padre', 'Armando', 'Administrador', 'activo'), 
(7, 'pueba', 'jose', '7c222fb2927d828af22f592134e8932480637c0d', 'Nombre de mi Madre', 'maria', 'Especialista', 'activo');

SET FOREIGN_KEY_CHECKS = 1;
COMMIT;
SET AUTOCOMMIT = 1; 
